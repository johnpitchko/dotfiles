return {
  -- Disable because I hate it
  { "echasnovski/mini.pairs", enabled = false },
}
